# core/views.py
from django.shortcuts import render

def home(request):
    return render(request, 'home.html')

def equipo(request):
    return render(request, 'page-employees.html')  # crea esta plantilla

def tasks_list(request):
    return render(request, 'page-task-list.html')  # crea esta plantilla

def account_settings(request):
    return render(request, 'page-account-settings.html')  # crea esta plantilla


def calendar(request):
    return render(request, 'calendar-full.html')  # crea esta plantilla
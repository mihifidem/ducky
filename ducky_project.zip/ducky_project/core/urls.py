from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('equipo/', views.equipo, name='equipo'),
    path('tasks-list/', views.tasks_list, name='tasks-list'),
    path('account-settings/', views.account_settings, name='account-settings'),
    path('calendar/', views.calendar, name='calendar'),

]